package test

import scala.io.StdIn.readLine
import java.io.File
import scala.collection.mutable.ListBuffer

import scala.io.Source
import scala.util.Try

object Program {

  case class Index(file:File,content:String) // TODO: Implement this


  sealed trait ReadFileError

  case object MissingPathArg extends ReadFileError
  case class NotDirectory(error: String) extends ReadFileError
  case class FileNotFound(t: Throwable) extends ReadFileError

  def readFile(args: Array[String]): Either[ReadFileError, File] = {
    for {
      path <- args.headOption.toRight(MissingPathArg)
      file <- Try(new java.io.File(path))
        .fold(
          throwable => Left(FileNotFound(throwable)),
          file =>
            if (file.isDirectory) Right(file)
            else Left(NotDirectory(s"Path [$path] is not a directory"))
        )
    } yield file
  }

  // TODO: Index all files in the directory
  def index(file: File): Index = {
    val content = Source.fromFile(file).getLines().mkString
    Index(file,content)
  }


  def iterate(indexedFiles: Index): Unit = {

    print(s"search> ")
    val searchString = readLine()
    // TODO: Make it print the ranking of each file and its corresponding score


    val countKeyFileValue =  new ListBuffer[Map[String,Int]]()
    val fileName = indexedFiles.file.toString
    val counts = indexedFiles.content.flatMap(_).groupBy(_).mapValues(_.size)(searchString)
    countKeyFileValue ++=  Map(fileName -> counts )
   countKeyFileValue.sorted
    if(countKeyFileValue.length < 10)
    for (i <- 0 until countKeyFileValue.length)
      println(s"file : $fileName and counts :  ${countKeyFileValue(i)(fileName)}")
    iterate(indexedFiles)
  }

}
